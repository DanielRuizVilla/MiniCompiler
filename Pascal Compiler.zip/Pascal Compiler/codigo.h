#ifndef __CODIGO_H__
#define __CODIGO_H__

typedef struct cuadrupla *operacion;
typedef struct codigo *listaOp;

operacion nueva_operacion(char *op, char *res, char *arg1, char * arg2);
listaOp nuevo_codigo(); 
void concatenar_operacion(listaOp l, operacion o);
void concatena_codigos(listaOp l1, listaOp l2); 
char *concatenar(char *prefijo, char * sufijo);
char *concatenar_i(char *prefijo, int i);
void borrar_operacion(operacion o); 
void borrar_codigo(listaOp l); 
void borrar_codigo_completo(listaOp l); 
void liberar_registro(char * r);
char * obtener_registro();   
char * obtener_resultado(listaOp l); 
char * obtener_etiqueta();	// $lx
char * crear_etiqueta();
void imprimir(listaOp l);           



#endif

