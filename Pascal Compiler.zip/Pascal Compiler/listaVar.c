#include "listaVar.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct nodo {
	char *nombre;
	int linea;
	struct nodo* sig;

};

lista crearLista(){
	struct nodo * lista = malloc(sizeof(struct nodo));
	lista->linea=0;
	lista->nombre=NULL;
	lista->sig=NULL;
	return lista;
}

void insertarVar(lista *l, char *nombre, int linea){
	struct nodo *aux = (struct nodo*) malloc(sizeof(struct nodo));
	if (aux == NULL){
		fprintf(stderr,"No memory, brother!\n");
		exit(1);
	}			 
	aux->nombre = nombre;
	aux->linea = linea;
	struct nodo * primero = *l;
	struct nodo * anterior = NULL;							// ESTO ¿? eduardo
	while(primero!= NULL){
		 anterior = primero;
		 primero = primero->sig;
	}	
	anterior->sig = aux;
	aux->sig = NULL;
}


int consultarVar(lista l, char *nombre){
	struct nodo *aux = l;
	while ((aux->sig != NULL) && (strcmp(aux->sig->nombre,nombre) != 0)){
		aux = aux->sig;	
	}
	if(aux->sig==NULL){
		printf("La variable que has intentado buscar no fue encontrada\n");
		return 0;
	}
	else return aux->sig->linea;							
}

void borrar(lista l){
	struct nodo * aux = l;
	while (aux != NULL){
		l = aux->sig;
		if (aux->nombre != NULL) free(aux->nombre);
		free(aux);
		aux = l;
	}
	
}

void imprimirlista(lista l){
struct nodo *aux = l->sig;
	while (aux != NULL){
		printf("_%s:\n\t.word 0\n",aux->nombre);
		aux = aux->sig;	
	}
}


