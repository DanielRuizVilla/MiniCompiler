#include "listaCad.h"
#include "codigo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int contador=1; 

struct nodoCad {
	char *nombre;
	char *etiqueta;
	struct nodoCad* sig;
};

listaCad crearListaCad(){
	struct nodoCad * listaCad = malloc(sizeof(struct nodoCad));
	listaCad->sig=NULL;
	return listaCad;
}

char * insertarCad(listaCad l, char *nombre){

	struct nodoCad *aux = (struct nodoCad*) malloc(sizeof(struct nodoCad));
	if (aux == NULL){
		fprintf(stderr,"No memory, brother!\n");
		exit(1);
	}			 
	aux->nombre = nombre;
	aux->etiqueta = concatenar_i("$str",contador);
	aux->sig = NULL;
	contador++;
	struct nodoCad * primero = l;
	struct nodoCad * anterior = NULL;
	while (primero!= NULL){
		 anterior = primero;
		 primero = primero->sig;
	}																	
	anterior->sig = aux;
	return aux->etiqueta;
}

void borrarCad(listaCad l){
	struct nodoCad * aux = l;
	while (aux != NULL){
		l = aux->sig;
		if (aux->nombre != NULL) free(aux->nombre);
		free(aux);
		aux = l;
	}
}

void imprimirCad(listaCad l){
struct nodoCad *aux = l->sig;
	while (aux != NULL){
		printf("%s:\n\t.asciiz %s\n",aux->etiqueta,aux->nombre);
		aux = aux->sig;	
	}
}






