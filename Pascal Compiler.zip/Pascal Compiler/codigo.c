#include "codigo.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int nEtiqueta = 1;
int registros[10] = {0};


struct cuadrupla {
	char *op;
	char *arg1;
	char *arg2;
	char * res;
	struct cuadrupla *sig;

};

struct codigo{
	struct cuadrupla *prim;
	struct cuadrupla *ult;
	//char *res;
};

operacion nueva_operacion(char *op, char *res, char *arg1, char * arg2){
	struct cuadrupla * aux = malloc(sizeof(struct cuadrupla));
	aux->op = op;
	aux->res = res;
	aux->arg1 = arg1;
	aux->arg2 = arg2;
	aux->sig = NULL;
	return aux;
}

char *obtener_resultado(listaOp l){
	if (l == NULL) return NULL;
	if (l->ult == NULL) return NULL;
	return l->ult->res;
}

void liberar_registro(char * r){
	// r es de la forma $tx
	// Necesito obtener X como un entero
	int i = (r[2]- '0');
	registros[i] = 0;

}

char * concatenar(char *prefijo, char * sufijo){

	char aux[256];
	snprintf(aux,256,"%s%s",prefijo,sufijo);
	return strdup(aux);
}

char * concatenar_i(char*prefijo,int i){
	char aux[256];
	snprintf(aux,256,"%s%d",prefijo,i);
	return strdup(aux);

}

listaOp nuevo_codigo(){
	struct codigo * lista = malloc(sizeof(struct codigo));
	lista->prim = lista->ult = NULL;
	return lista;
}

void concatenar_operacion(listaOp l, operacion o){
	if(l->prim != NULL) {
		l->ult->sig = o;
		l->ult = o;
	}
	else{			
		l->prim = o;
		l->ult = o;				
	}
}

void concatena_codigos(listaOp l1, listaOp l2){

	if(l1->ult != NULL && l2->prim != NULL){
		l1->ult->sig = l2->prim;
		l1->ult = l2->ult;
	}
	else if (l2->prim != NULL) {
		*l1 = *l2;       // Si no es asi, sería l1 = l2;
	}

}

void borrar_operacion(operacion o){

	free(o->arg1);
	free(o->arg2);
	free(o->op);
	o->sig=NULL;	
	free(o);
}

void borrar_codigo(listaOp l) {
	//if(l->res != NULL) free(l->res);
	free(l);
}

void borrar_codigo_completo(listaOp l){

	struct cuadrupla* aux = l->prim;
	while(aux != NULL){
		l->prim = aux->sig;
		if(aux->op != NULL) free(aux->op);
		if(aux->arg1 != NULL) free(aux->arg1);
		if(aux->arg2 != NULL) free(aux->arg2);
		free(aux);																	
		aux = l->prim;
	}
	//if(l->res != NULL) free(l->res);
	free(l);
}

char *  obtener_registro(){

	int i;
	for(i=0; i < 10; i++){
		if (registros[i] == 0) break;
	}
	if (i == 10){
		printf("Error: Los registros están agotados, sentimos las molestias.\n");
		exit(1);
	}
	registros[i] = 1;
	return concatenar_i("$t",i);
}


void imprimir(listaOp l){

	struct cuadrupla * aux = l->prim;
	printf("\n####################\n");
	printf("# Sección de código \n");
	printf("\t .text\n");
	printf("\t .globl main\n");
	printf("main :\n");
	while(aux!=NULL){
		if((aux->op!=NULL) && (aux->op[0] == '$'))	printf("%s:", aux->op);
		else if(aux->op !=NULL)				printf("	%s	",aux->op);
		if(aux->res != NULL)				printf("%s", aux->res);
		if(aux->arg1 != NULL)				printf(", %s", aux->arg1);
		if(aux->arg2 != NULL)				printf(", %s", aux->arg2);
		printf("\n");
		aux = aux->sig;
	}
	printf("####################\n");
	printf("# FIN\n");	
	printf("\tjr	$ra\n");
}

char * crear_etiqueta(){

	char * resultado = (char*) malloc(sizeof(char)*5);
	sprintf(resultado, "$l%d", nEtiqueta);
	nEtiqueta++;
	return resultado;
}


