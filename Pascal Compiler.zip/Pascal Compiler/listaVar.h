#ifndef __LISTA_VAR_H__
#define __LISTA_VAR_H__

typedef struct nodo *lista;

lista crearLista();
void insertarVar(lista *l, char *nombre, int linea);
int consultarVar(lista l, char *nombre);
void borrar(lista l);
void imprimirlista(lista l);

#endif
