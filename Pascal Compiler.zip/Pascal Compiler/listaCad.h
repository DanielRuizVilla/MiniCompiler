#ifndef __LISTA_CAD_H__
#define __LISTA_CAD_H__

typedef struct nodoCad *listaCad;

listaCad crearListaCad();
char * insertarCad(listaCad l, char *nombre);
int consultarCad(listaCad l, char *nombre);
void borrarCad(listaCad l);
void imprimirCad(listaCad l);


#endif
